package com.mypurecloud.sdk.v2.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import java.util.Objects;
import java.util.ArrayList;
import java.io.IOException;
import com.mypurecloud.sdk.v2.ApiClient;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mypurecloud.sdk.v2.model.AgentBidScheduleSetOverrideRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;

import java.io.Serializable;
/**
 * AgentsBidAssignedScheduleSetOverrideRequest
 */

public class AgentsBidAssignedScheduleSetOverrideRequest  implements Serializable {
  
  private List<AgentBidScheduleSetOverrideRequest> agentScheduleSetOverrides = null;

  public AgentsBidAssignedScheduleSetOverrideRequest() {
    if (ApiClient.LEGACY_EMPTY_LIST == true) { 
      agentScheduleSetOverrides = new ArrayList<AgentBidScheduleSetOverrideRequest>();
    }
  }

  public AgentsBidAssignedScheduleSetOverrideRequest(Boolean initWithEmptyList) {
    if (initWithEmptyList == true) { 
      agentScheduleSetOverrides = new ArrayList<AgentBidScheduleSetOverrideRequest>();
    }
  }

  
  /**
   * The agent schedule set overrides
   **/
  public AgentsBidAssignedScheduleSetOverrideRequest agentScheduleSetOverrides(List<AgentBidScheduleSetOverrideRequest> agentScheduleSetOverrides) {
    this.agentScheduleSetOverrides = agentScheduleSetOverrides;
    return this;
  }
  
  @ApiModelProperty(example = "null", required = true, value = "The agent schedule set overrides")
  @JsonProperty("agentScheduleSetOverrides")
  public List<AgentBidScheduleSetOverrideRequest> getAgentScheduleSetOverrides() {
    return agentScheduleSetOverrides;
  }
  public void setAgentScheduleSetOverrides(List<AgentBidScheduleSetOverrideRequest> agentScheduleSetOverrides) {
    this.agentScheduleSetOverrides = agentScheduleSetOverrides;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AgentsBidAssignedScheduleSetOverrideRequest agentsBidAssignedScheduleSetOverrideRequest = (AgentsBidAssignedScheduleSetOverrideRequest) o;

    return Objects.equals(this.agentScheduleSetOverrides, agentsBidAssignedScheduleSetOverrideRequest.agentScheduleSetOverrides);
  }

  @Override
  public int hashCode() {
    return Objects.hash(agentScheduleSetOverrides);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AgentsBidAssignedScheduleSetOverrideRequest {\n");
    
    sb.append("    agentScheduleSetOverrides: ").append(toIndentedString(agentScheduleSetOverrides)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

